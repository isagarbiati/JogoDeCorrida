
function setup() {
  createCanvas(400, 400);
}

let xJogador = [0, 0 ,0];
let yJogador = [75,150,225, 300];
let Jogador  = ["🥵", "😝", "😍", "🥶"];
let teclas   = ["a", "s", "d", "f"]
let quantidade = jogador. length;
                
 function draw() { 
  ativaJogo();
   desenhajogadores();
   desenhalinhadechegada();
   verificavencedor();
 }

function ativaJogo() { 
  if (focused == true) } 
    background("#D2EBB5");
 
   background("rgb (238,178,178)");
  }
  
 function desenhaJogadores() {
   textSize(40);
   for (let i = 0; i < quantidade; i++)   {
     text (jogador[i], xJogador[i]; yJogador[i]);
   }
 }

function desenhaLinhaDeChegada() { 
  fill("white")
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < )



}
     